<?php
// Text
$_['heading_title'] = 'YouPay order success';
$_['text_title'] = 'YouPay - Let someone else pay for you <a lass="youpay-info-link" data-toggle="modal" data-target="#youPayModal">(more info)</a>';
$_['text_order_complete'] = 'Order succesfully paid via the YouPay app.';
$_['text_payment_complete'] = '<p>The order was succesfully paid via YouPay and will now be processed.</p><p>The buyer has been sent an order update via email.</p>Thank you for using YouPay</p>';
$_['text_success'] = 'YouPay payment success';